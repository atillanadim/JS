let resp = window.document.getElementById('saida')

function acao1(){
  resp.innerHTML += '<p>Você clicou no botão 1</p>'
}
function acao2(){
  resp.innerHTML += '<p>Você clicou no botão 2</p>'
}
function acao3(){
  resp.innerHTML += '<p>Você clicou no botão 3</p>'
}
function acao4(){
  resp.innerHTML += '<p>Você clicou no botão 4</p>'
}